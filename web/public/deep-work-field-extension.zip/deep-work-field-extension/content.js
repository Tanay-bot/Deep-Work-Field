"use strict";
(() => {
  // shared/src/types.ts
  var CHECKPOINT_SCHEMA_VERSION = 1;

  // shared/src/fragments.ts
  function foldCase(text) {
    let out = "";
    for (const ch of text) {
      const lower = ch.toLowerCase();
      out += lower.length === ch.length ? lower : ch;
    }
    return out;
  }
  function normalizePassage(text) {
    return text.replace(/\s+/g, " ").trim();
  }

  // shared/src/verify.ts
  var BLOCK_TAGS = /* @__PURE__ */ new Set([
    "ADDRESS",
    "ARTICLE",
    "ASIDE",
    "BLOCKQUOTE",
    "DD",
    "DIV",
    "DL",
    "DT",
    "FIELDSET",
    "FIGCAPTION",
    "FIGURE",
    "FOOTER",
    "FORM",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "HEADER",
    "HR",
    "LI",
    "MAIN",
    "NAV",
    "OL",
    "P",
    "PRE",
    "SECTION",
    "TABLE",
    "TBODY",
    "TD",
    "TH",
    "TR",
    "UL"
  ]);
  function buildTextIndex(root) {
    const doc = root.nodeType === 9 ? root : root.ownerDocument;
    const map = [];
    const breaks = /* @__PURE__ */ new Set();
    let text = "";
    if (!doc) return { text, map, breaks };
    const view = doc.defaultView;
    const blockCache = /* @__PURE__ */ new Map();
    const hiddenCache = /* @__PURE__ */ new Map();
    const isHidden = (el) => {
      const cached = hiddenCache.get(el);
      if (cached !== void 0) return cached;
      let hidden = false;
      const style = view?.getComputedStyle(el);
      if (style && (style.display === "none" || style.visibility === "hidden")) hidden = true;
      else if (el.parentElement) hidden = isHidden(el.parentElement);
      hiddenCache.set(el, hidden);
      return hidden;
    };
    const blockOf = (el) => {
      const cached = blockCache.get(el);
      if (cached) return cached;
      let current = el;
      while (current.parentElement) {
        const display = view?.getComputedStyle(current).display ?? "";
        const inline = display ? display.startsWith("inline") || display === "contents" : !BLOCK_TAGS.has(current.tagName.toUpperCase());
        if (!inline) break;
        current = current.parentElement;
      }
      blockCache.set(el, current);
      return current;
    };
    const walker = doc.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node2) {
        const parent = node2.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        if (parent.closest("script,style,noscript,template,textarea,select,option,head,title,svg,canvas")) return NodeFilter.FILTER_REJECT;
        if (isHidden(parent)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let previousBlock = null;
    let node;
    while (node = walker.nextNode()) {
      const tn = node;
      const parent = tn.parentElement;
      if (!parent) continue;
      const block = blockOf(parent);
      if (text.length > 0 && previousBlock !== null && block !== previousBlock) {
        if (text.endsWith(" ")) breaks.add(text.length - 1);
        else {
          breaks.add(text.length);
          text += " ";
          map.push({ node: tn, offset: 0 });
        }
      }
      const data = tn.data;
      for (let i = 0; i < data.length; i++) {
        const ch = data[i];
        if (/\s/.test(ch)) {
          if (text.length === 0 || text.endsWith(" ")) continue;
          text += " ";
          map.push({ node: tn, offset: i });
        } else {
          const lower = ch.toLowerCase();
          text += lower.length === 1 ? lower : ch;
          map.push({ node: tn, offset: i });
        }
      }
      if (data.trim()) previousBlock = block;
    }
    return { text, map, breaks };
  }
  function rangeFor(index, start, end) {
    const first = index.map[start];
    const last = index.map[end - 1];
    if (!first || !last) return null;
    try {
      const range = first.node.ownerDocument.createRange();
      range.setStart(first.node, first.offset);
      range.setEnd(last.node, last.offset + 1);
      return range;
    } catch {
      return null;
    }
  }
  function isRectInViewport(rect, view) {
    return rect.height > 0 && rect.bottom > 0 && rect.top < view.innerHeight && rect.right > 0 && rect.left < view.innerWidth;
  }
  function rangeVisible(range, view) {
    const rects = Array.from(range.getClientRects()).filter((r2) => r2.width > 0 && r2.height > 0);
    if (rects.length === 0) return false;
    if (!rects.every((r2) => isRectInViewport(r2, view))) return false;
    const r = rects[0];
    const hit = view.document.elementFromPoint?.(r.left + Math.min(r.width / 2, 20), r.top + r.height / 2);
    const host = range.startContainer.parentElement;
    return !hit || !host || hit === host || host.contains(hit) || hit.contains(host);
  }
  function verifyCheckpointOnce(doc, checkpoint) {
    const view = doc.defaultView;
    const base = { match: false, inViewport: false, reason: "unreadable", candidates: 0, contextMatches: 0 };
    if (!view) return base;
    const anchor = foldCase(normalizePassage(checkpoint.anchor));
    const prefix = foldCase(normalizePassage(checkpoint.prefix));
    const suffix = foldCase(normalizePassage(checkpoint.suffix));
    if (!anchor) return { ...base, reason: "no-match" };
    const index = buildTextIndex(doc);
    let from = 0;
    let candidates = 0;
    let survivors = [];
    while (true) {
      const start = index.text.indexOf(anchor, from);
      if (start === -1) break;
      from = start + 1;
      candidates++;
      const end = start + anchor.length;
      if (prefix) {
        const before = index.text.slice(Math.max(0, start - prefix.length - 8), start).trim();
        if (!before.endsWith(prefix)) continue;
      }
      if (suffix) {
        const after = index.text.slice(end, end + suffix.length + 8).trim();
        if (!after.startsWith(suffix)) continue;
      }
      const range = rangeFor(index, start, end);
      if (range) survivors.push({ start, end, range });
    }
    if (survivors.length > 1 && checkpoint.selectorHint) {
      let scoped = [];
      try {
        scoped = survivors.filter((s) => !!s.range.startContainer.parentElement?.closest(checkpoint.selectorHint));
      } catch {
        scoped = [];
      }
      if (scoped.length >= 1) survivors = scoped;
    }
    const contextMatches = survivors.length;
    if (contextMatches === 0) {
      return { ...base, reason: candidates > 0 ? "context-mismatch" : "no-match", candidates };
    }
    if (contextMatches > 1) {
      return { ...base, reason: "ambiguous", candidates, contextMatches };
    }
    const only = survivors[0];
    const rect = only.range.getBoundingClientRect();
    const visible = rangeVisible(only.range, view);
    return {
      match: true,
      inViewport: visible,
      reason: visible ? "ok" : "not-in-viewport",
      candidates,
      contextMatches,
      matchedText: index.text.slice(only.start, only.end),
      range: only.range,
      rect: { top: rect.top, bottom: rect.bottom, left: rect.left, right: rect.right }
    };
  }
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function verifyCheckpointAsync(doc, checkpoint, options = {}) {
    const attempts = options.attempts ?? 12;
    const retryMs = options.retryMs ?? 250;
    const scrollAfter = options.scrollAfter ?? 2;
    let last = { match: false, inViewport: false, reason: "unreadable", candidates: 0, contextMatches: 0 };
    let scrolled = false;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      if (!doc.defaultView) {
        return { ok: false, reason: "unreadable", candidates: 0, attempts: attempt };
      }
      last = verifyCheckpointOnce(doc, checkpoint);
      if (last.match && last.inViewport) {
        return {
          ok: true,
          reason: "ok",
          candidates: last.candidates,
          contextMatches: last.contextMatches,
          landing: scrolled ? "dom-scroll" : "native",
          rect: last.rect,
          matchedText: last.matchedText,
          range: last.range,
          attempts: attempt
        };
      }
      if (last.reason === "ambiguous" && doc.readyState === "complete") break;
      if (!scrolled && attempt > scrollAfter && last.match && last.range) {
        scrolled = true;
        try {
          const parent = last.range.startContainer.parentElement;
          parent?.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" });
        } catch {
        }
      }
      await sleep(retryMs);
    }
    return {
      ok: false,
      reason: last.reason === "ok" ? "not-in-viewport" : last.reason,
      candidates: last.candidates,
      contextMatches: last.contextMatches,
      rect: last.rect,
      matchedText: last.matchedText,
      attempts
    };
  }

  // shared/src/checkpoint.ts
  function newId(prefix = "id") {
    const c = globalThis.crypto;
    if (c && "randomUUID" in c) return `${prefix}_${c.randomUUID()}`;
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }
  function slugify(text) {
    return normalizePassage(text).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48) || "spot";
  }
  function wordContext(index, start, end) {
    const beforeWindowStart = Math.max(0, start - 52);
    let prefix = index.text.slice(beforeWindowStart, start).trim();
    const firstSpace = prefix.indexOf(" ");
    if (beforeWindowStart > 0 && firstSpace !== -1) prefix = prefix.slice(firstSpace + 1);
    const afterWindowEnd = Math.min(index.text.length, end + 52);
    let suffix = index.text.slice(end, afterWindowEnd).trim();
    const lastSpace = suffix.lastIndexOf(" ");
    if (afterWindowEnd < index.text.length && lastSpace !== -1) suffix = suffix.slice(0, lastSpace);
    return { prefix, suffix };
  }
  function fragmentTerms(index, start, end) {
    const words = (t, n, fromEnd) => {
      const parts = t.trim().split(" ").filter(Boolean);
      return (fromEnd ? parts.slice(-n) : parts.slice(0, n)).join(" ");
    };
    const breaksIn = (a, b) => [...index.breaks].filter((i) => i >= a && i < b).sort((x, y) => x - y);
    let pEnd = start;
    while (pEnd > 0 && index.text[pEnd - 1] === " ") pEnd--;
    const before = breaksIn(0, pEnd);
    const prefix = words(index.text.slice(before.length ? before[before.length - 1] + 1 : 0, pEnd), 6, true);
    let sStart = end;
    while (sStart < index.text.length && index.text[sStart] === " ") sStart++;
    const after = breaksIn(sStart, index.text.length);
    const suffix = words(index.text.slice(sStart, after.length ? after[0] : index.text.length), 6, false);
    const inner = breaksIn(start, end);
    if (inner.length === 0) return { prefix, start: index.text.slice(start, end), suffix };
    return {
      prefix,
      start: words(index.text.slice(start, inner[0]), 6, false),
      end: words(index.text.slice(inner[inner.length - 1] + 1, end), 6, true),
      suffix
    };
  }
  function buildCheckpoint(doc, index, start, end, anchor, host, options) {
    const view = doc.defaultView;
    if (!view) return null;
    const { prefix, suffix } = wordContext(index, start, end);
    const problemHost = host?.closest("[data-problem-id]");
    const problemId = options.problemId ?? problemHost?.dataset.problemId ?? slugify(anchor).split("-").slice(0, 3).join("-");
    return {
      schemaVersion: CHECKPOINT_SCHEMA_VERSION,
      id: newId("cp"),
      createdAt: Date.now(),
      goal: options.goal ?? "",
      url: view.location.href.split("#")[0],
      docId: `${view.location.origin}${view.location.pathname}`,
      problemId,
      anchor,
      prefix,
      suffix,
      title: doc.title || view.location.hostname,
      selectorHint: problemHost ? `[data-problem-id="${problemHost.dataset.problemId}"]` : void 0,
      savedFrame: options.savedFrame,
      answerRegion: options.answerRegion,
      fragment: fragmentTerms(index, start, end)
    };
  }
  function captureCheckpointFromRange(doc, range, options = {}) {
    const index = buildTextIndex(doc);
    let start = -1;
    let end = -1;
    for (let i = 0; i < index.map.length; i++) {
      const entry = index.map[i];
      let inside = false;
      try {
        inside = range.comparePoint(entry.node, entry.offset) === 0 && !(entry.node === range.endContainer && entry.offset >= range.endOffset);
      } catch {
        inside = false;
      }
      if (inside) {
        if (start === -1) start = i;
        end = i + 1;
      } else if (start !== -1) {
        break;
      }
    }
    if (start === -1) return null;
    while (start < end && index.text[start] === " ") start++;
    while (end > start && index.text[end - 1] === " ") end--;
    if (end <= start) return null;
    if (end - start > 140) {
      const cut = index.text.lastIndexOf(" ", start + 140);
      end = cut > start ? cut : start + 140;
    }
    const original = normalizePassage(rangeText(index, start, end));
    if (foldCase(original) !== index.text.slice(start, end)) return null;
    const host = range.startContainer.nodeType === 1 ? range.startContainer : range.startContainer.parentElement;
    return buildCheckpoint(doc, index, start, end, original, host, options);
  }
  function rangeText(index, start, end) {
    let out = "";
    for (let i = start; i < end; i++) {
      const entry = index.map[i];
      const ch = entry.node.data[entry.offset] ?? " ";
      out += /\s/.test(ch) || index.text[i] === " " ? " " : ch;
    }
    return out;
  }
  function captureCheckpointFromElement(doc, element, options = {}) {
    const anchorElement = element.matches("h1,h2,h3,h4,h5,h6,p,li,td,label") ? element : element.querySelector("h1,h2,h3,h4,h5,h6,[data-anchor-text]") ?? element;
    const anchorText = normalizePassage(options.anchorText ?? anchorElement.textContent ?? "");
    if (!anchorText) return null;
    const anchor = anchorText.length > 140 ? anchorText.slice(0, 140).replace(/\s+\S*$/, "") : anchorText;
    const folded = foldCase(anchor);
    const index = buildTextIndex(doc);
    let start = -1;
    let from = 0;
    while (true) {
      const found = index.text.indexOf(folded, from);
      if (found === -1) break;
      const entry = index.map[found];
      if (entry && anchorElement.contains(entry.node)) {
        start = found;
        break;
      }
      from = found + 1;
    }
    if (start === -1) return null;
    return buildCheckpoint(doc, index, start, start + folded.length, anchor, anchorElement, options);
  }
  function pickAnchorElement(doc) {
    const selection = doc.getSelection();
    if (selection && !selection.isCollapsed && selection.rangeCount > 0) {
      const node = selection.getRangeAt(0).startContainer;
      const el = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
      const meaningful = el?.closest("h1,h2,h3,h4,h5,h6,p,li,td,label,[data-problem-id]");
      if (meaningful) return meaningful;
      if (el) return el;
    }
    const view = doc.defaultView;
    const vh = view?.innerHeight ?? 800;
    const candidates = Array.from(doc.querySelectorAll("h1,h2,h3,h4,h5,h6,[data-problem-id]"));
    let best = null;
    let bestDistance = Infinity;
    for (const el of candidates) {
      const rect = el.getBoundingClientRect();
      if (rect.height <= 0 || rect.bottom <= 0 || rect.top >= vh) continue;
      const distance = Math.abs(rect.top + rect.height / 2 - vh / 2);
      if (distance < bestDistance) {
        best = el;
        bestDistance = distance;
      }
    }
    return best;
  }

  // extension/src/content.ts
  var activeCheckpoint = null;
  var editLogged = false;
  var detachEdit = null;
  function shadowHost(id) {
    let host = document.getElementById(id);
    if (!host) {
      host = document.createElement("div");
      host.id = id;
      host.style.cssText = "position:fixed;z-index:2147483647;top:16px;right:16px;max-width:360px;font-family:ui-sans-serif,system-ui,sans-serif";
      document.documentElement.appendChild(host);
    }
    const root = host.shadowRoot ?? host.attachShadow({ mode: "open" });
    return { host, root };
  }
  function removeOverlay(id) {
    document.getElementById(id)?.remove();
  }
  function showSuccess(checkpoint, result) {
    removeOverlay("dwf-saved-context");
    const { host, root } = shadowHost("dwf-restored");
    host.style.cssText += ";top:16px;right:16px";
    root.innerHTML = `
    <style>
      .card{background:#0f766e;color:#f0fdfa;border-radius:12px;padding:12px 15px;box-shadow:0 14px 40px rgba(15,118,110,.35);font-size:13px;line-height:1.45}
      b{display:block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;opacity:.8;margin-bottom:3px}
      small{display:block;opacity:.78;font-size:11px;margin-top:4px}
    </style>
    <div class="card"><b>Verified restore</b>${checkpoint.anchor.replace(/</g, "&lt;")}
      <small>prefix/suffix matched \xB7 passage in viewport \xB7 ${result.attempts} attempt(s)</small></div>`;
    setTimeout(() => host.remove(), 7e3);
  }
  function showSavedContext(checkpoint, result) {
    removeOverlay("dwf-restored");
    const { root } = shadowHost("dwf-saved-context");
    const frame = checkpoint.savedFrame ? `<img alt="Last on-task frame" src="${checkpoint.savedFrame}" style="max-width:100%;border-radius:7px;margin-top:8px;border:1px solid #334155" />` : "";
    root.innerHTML = `
    <style>
      .card{background:#111a2b;color:#e7eefb;border:1px solid #3b4a63;border-radius:12px;padding:14px 16px;box-shadow:0 14px 40px rgba(0,0,0,.45);font-size:13px;line-height:1.5}
      .tag{display:inline-block;background:rgba(240,180,41,.14);color:#f0b429;border:1px solid rgba(240,180,41,.4);border-radius:999px;padding:2px 8px;font-size:9px;letter-spacing:.12em;text-transform:uppercase;margin-bottom:6px}
      .anchor{font-family:Georgia,serif;font-size:15px;margin:0 0 6px}
      .ctx{font-family:ui-monospace,monospace;font-size:10px;color:#93a3bc;word-break:break-word}
      .reason{color:#ffc2b1;font-size:11.5px;margin-top:7px}
      button{position:absolute;right:10px;top:8px;background:transparent;border:0;color:#93a3bc;font-size:18px;cursor:pointer}
      small{display:block;color:#93a3bc;font-size:10.5px;margin-top:7px}
    </style>
    <div class="card" role="status">
      <button id="dwf-close" aria-label="Dismiss">\xD7</button>
      <span class="tag">Saved context only</span>
      <p class="anchor">${checkpoint.anchor.replace(/</g, "&lt;")}</p>
      <div class="ctx">\u2026 ${checkpoint.prefix.replace(/</g, "&lt;")} [${checkpoint.anchor.replace(/</g, "&lt;")}] ${checkpoint.suffix.replace(/</g, "&lt;")} \u2026</div>
      <div class="reason">${result.reason === "ambiguous" ? `Multiple matching passages: ${result.contextMatches ?? "several"} places have the same text before and after it, so none was picked.` : result.reason === "context-mismatch" ? "The surrounding text did not match the checkpoint." : result.reason === "not-in-viewport" ? "The passage never landed inside the viewport." : result.reason === "no-match" ? "The saved passage was not found on this page." : "The page could not be verified."}</div>
      ${frame}
      <small>Nothing was verified, so Deep Work Field is not claiming a resume.</small>
    </div>`;
    root.querySelector("#dwf-close")?.addEventListener("click", () => document.getElementById("dwf-saved-context")?.remove());
  }
  async function verifyPending() {
    let pending = null;
    for (let attempt = 0; attempt < 5 && !pending?.checkpoint; attempt++) {
      if (attempt) await new Promise((resolve) => setTimeout(resolve, 250));
      try {
        pending = (await chrome.runtime.sendMessage({ type: "DWF_GET_PENDING" }))?.pending ?? null;
      } catch {
        return;
      }
    }
    if (!pending?.checkpoint) return;
    const checkpoint = pending.checkpoint;
    activeCheckpoint = checkpoint;
    await new Promise((resolve) => setTimeout(resolve, 500));
    const result = await verifyCheckpointAsync(document, checkpoint, {
      attempts: 14,
      retryMs: 300,
      scrollAfter: 2
    });
    const { range, ...plain } = result;
    try {
      await chrome.runtime.sendMessage({ type: "DWF_VERIFY_RESULT", checkpointId: checkpoint.id, restoreId: pending.restoreId, result: plain });
    } catch {
    }
    if (result.ok) {
      showSuccess(checkpoint, result);
      attachEditTracking(checkpoint, range);
    } else {
      showSavedContext(checkpoint, result);
    }
  }
  function attachEditTracking(checkpoint, verified) {
    detachEdit?.();
    detachEdit = null;
    const origin = verified?.startContainer.parentElement ?? null;
    const host = origin?.closest("[data-answer-region],[data-problem-id],section,form,fieldset") ?? (checkpoint.selectorHint ? document.querySelector(checkpoint.selectorHint) : null);
    const field = host?.querySelector('textarea,input,[contenteditable="true"]');
    if (!field) return;
    const read = () => "value" in field ? String(field.value ?? "") : field.textContent ?? "";
    const baseline = read();
    const handler = () => {
      if (editLogged || activeCheckpoint?.id !== checkpoint.id) return;
      const value = read();
      const added = value.length - baseline.length;
      const newline = (value.match(/\n/g)?.length ?? 0) > (baseline.match(/\n/g)?.length ?? 0);
      if (added < 10 && !newline) return;
      editLogged = true;
      try {
        chrome.runtime.sendMessage({ type: "DWF_ANSWER_EDIT", problemId: checkpoint.problemId, checkpointId: checkpoint.id, chars: added });
      } catch {
      }
    };
    field.addEventListener("input", handler);
    detachEdit = () => field.removeEventListener("input", handler);
  }
  function capture(goal, sendResponse) {
    const selection = window.getSelection();
    const range = selection && !selection.isCollapsed && selection.rangeCount > 0 ? selection.getRangeAt(0) : null;
    let checkpoint = null;
    if (range) {
      checkpoint = captureCheckpointFromRange(document, range, { goal });
      if (!checkpoint) {
        sendResponse({ ok: false, error: "Your selection could not be mapped to the page text, so nothing was saved. Try selecting plain text in one paragraph." });
        return;
      }
    } else {
      const element = pickAnchorElement(document);
      if (!element) {
        sendResponse({ ok: false, error: "No heading or paragraph is visible to anchor." });
        return;
      }
      checkpoint = captureCheckpointFromElement(document, element, { goal });
      if (!checkpoint) {
        sendResponse({ ok: false, error: "The visible passage could not be indexed (it may be canvas-rendered)." });
        return;
      }
    }
    activeCheckpoint = checkpoint;
    editLogged = false;
    attachEditTracking(checkpoint, range ?? void 0);
    sendResponse({ ok: true, checkpoint });
  }
  var streamTimer = 0;
  function visibleText(limit = 1600) {
    const out = [];
    let length = 0;
    const walker = document.createTreeWalker(document.body ?? document.documentElement, NodeFilter.SHOW_TEXT);
    let node;
    const seen = /* @__PURE__ */ new Set();
    while ((node = walker.nextNode()) && length < limit) {
      const parent = node.parentElement;
      if (!parent || seen.has(parent) || !node.data.trim()) continue;
      if (parent.closest("script,style,noscript,template,svg")) continue;
      const r = parent.getBoundingClientRect();
      if (r.bottom <= 0 || r.top >= innerHeight || r.right <= 0 || r.left >= innerWidth || r.height === 0) continue;
      seen.add(parent);
      const t = node.data.replace(/\s+/g, " ").trim();
      out.push(t);
      length += t.length + 1;
    }
    return out.join(" ").slice(0, limit);
  }
  function sendScreen() {
    if (document.visibilityState !== "visible") return;
    try {
      chrome.runtime.sendMessage({ type: "DWF_SCREEN", url: location.href, title: document.title, text: visibleText() });
    } catch {
      stopStream();
    }
  }
  function startStream() {
    if (streamTimer) return;
    sendScreen();
    streamTimer = window.setInterval(sendScreen, 1e3);
  }
  function stopStream() {
    clearInterval(streamTimer);
    streamTimer = 0;
  }
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState !== "visible") stopStream();
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "DWF_STREAM") {
      if (message.on) startStream();
      else stopStream();
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type === "DWF_CAPTURE") {
      capture(String(message.goal ?? ""), sendResponse);
      return false;
    }
    if (message?.type === "DWF_VERIFY_NOW") {
      void verifyPending().then(() => sendResponse({ ok: true }));
      return true;
    }
    return false;
  });
  if (document.readyState === "complete" || document.readyState === "interactive") {
    void verifyPending();
  } else {
    window.addEventListener("DOMContentLoaded", () => void verifyPending(), { once: true });
  }
})();
