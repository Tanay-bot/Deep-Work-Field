"use strict";
(() => {
  // shared/src/fragments.ts
  function encodeFragmentTerm(text) {
    return encodeURIComponent(text).replace(/-/g, "%2D");
  }
  function normalizePassage(text) {
    return text.replace(/\s+/g, " ").trim();
  }
  function buildTextFragmentUrl(baseUrl, checkpoint) {
    const anchor = normalizePassage(checkpoint.anchor);
    const [base, hash = ""] = baseUrl.split("#");
    const ownHash = hash.split(":~:")[0];
    if (!anchor) return ownHash ? `${base}#${ownHash}` : base;
    const tail = (t) => normalizePassage(t).split(" ").filter(Boolean).slice(-6).join(" ");
    const head = (t) => normalizePassage(t).split(" ").filter(Boolean).slice(0, 6).join(" ");
    const f = checkpoint.fragment ?? { prefix: tail(checkpoint.prefix), start: anchor, suffix: head(checkpoint.suffix) };
    const parts = [];
    if (f.prefix) parts.push(`${encodeFragmentTerm(normalizePassage(f.prefix))}-`);
    parts.push(encodeFragmentTerm(normalizePassage(f.start)));
    if (f.end) parts.push(encodeFragmentTerm(normalizePassage(f.end)));
    if (f.suffix) parts.push(`-${encodeFragmentTerm(normalizePassage(f.suffix))}`);
    return `${base}#${ownHash}:~:text=${parts.join(",")}`;
  }

  // extension/src/background.ts
  var KEYS = {
    checkpoints: "dwf:checkpoints",
    pending: "dwf:pending",
    lastResult: "dwf:lastResult",
    session: "dwf:session"
  };
  var RESTORE_TIMEOUT_MS = 6e4;
  var storageLock = Promise.resolve();
  function withLock(fn) {
    const run = storageLock.then(fn, fn);
    storageLock = run.catch(() => void 0);
    return run;
  }
  function restoreId() {
    return `rs_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }
  async function readPending() {
    const stored = await chrome.storage.local.get(KEYS.pending);
    const raw = stored[KEYS.pending];
    if (!raw || typeof raw !== "object" || "checkpoint" in raw) return {};
    const now = Date.now();
    const live = {};
    for (const [tab, entry] of Object.entries(raw)) {
      if (entry && now - entry.at < RESTORE_TIMEOUT_MS) live[tab] = entry;
    }
    return live;
  }
  async function readCheckpoints() {
    const stored = await chrome.storage.local.get(KEYS.checkpoints);
    return Array.isArray(stored[KEYS.checkpoints]) ? stored[KEYS.checkpoints] : [];
  }
  async function writeCheckpoints(list) {
    await chrome.storage.local.set({ [KEYS.checkpoints]: list.slice(0, 25) });
  }
  async function getPending(tabId) {
    if (tabId === void 0) return null;
    const map = await readPending();
    return map[String(tabId)] ?? null;
  }
  async function settlePending(tabId, id) {
    return withLock(async () => {
      const map = await readPending();
      const entry = map[String(tabId)];
      if (!entry || entry.restoreId !== id) return false;
      delete map[String(tabId)];
      await chrome.storage.local.set({ [KEYS.pending]: map });
      return true;
    });
  }
  async function setBadge(text, color) {
    try {
      await chrome.action.setBadgeText({ text });
      await chrome.action.setBadgeBackgroundColor({ color });
    } catch {
    }
  }
  async function activeTab() {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return tab;
  }
  async function captureOnTab(tab, goal, screenshot = false) {
    if (!tab?.id) return { ok: false, error: "No active tab." };
    let reply = null;
    try {
      reply = await chrome.tabs.sendMessage(tab.id, { type: "DWF_CAPTURE", goal });
    } catch (error) {
      return { ok: false, error: "The content script is not available on this page (chrome:// pages and the Chrome Web Store cannot be captured)." };
    }
    if (!reply?.ok || !reply.checkpoint) {
      return { ok: false, error: reply?.error ?? "No citable passage was found on this page." };
    }
    const checkpoint = reply.checkpoint;
    try {
      const now = screenshot ? await activeTab() : null;
      if (now && now.id === tab.id && now.windowId === tab.windowId) {
        checkpoint.savedFrame = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 55 });
      }
    } catch {
    }
    await withLock(async () => {
      const list = await readCheckpoints();
      list.unshift(checkpoint);
      await writeCheckpoints(list);
    });
    await chrome.storage.local.set({ [KEYS.session]: { goal, checkpointId: checkpoint.id, startedAt: Date.now() } });
    await setBadge("\u25CF", "#45d6ab");
    return { ok: true, checkpoint: { ...checkpoint, savedFrame: void 0, answerRegion: void 0 } };
  }
  async function restoreCheckpoint(id) {
    const list = await readCheckpoints();
    const checkpoint = list.find((item) => item.id === id);
    if (!checkpoint) return { ok: false, error: "Checkpoint not found." };
    const isViewer = checkpoint.url.startsWith(chrome.runtime.getURL("pdf/viewer.html"));
    const url = isViewer ? checkpoint.url : buildTextFragmentUrl(checkpoint.url, checkpoint);
    let tab;
    try {
      tab = await chrome.tabs.create({ url, active: true });
    } catch (error) {
      return { ok: false, error: "Could not open a tab for the restore." };
    }
    if (!tab?.id) return { ok: false, error: "Could not open a tab for the restore." };
    const op = { restoreId: restoreId(), checkpoint, tabId: tab.id, at: Date.now() };
    await withLock(async () => {
      const map = await readPending();
      map[String(tab.id)] = op;
      await chrome.storage.local.set({
        [KEYS.pending]: map,
        [KEYS.lastResult]: { checkpointId: id, restoreId: op.restoreId, status: "pending", at: Date.now() }
      });
    });
    return { ok: true, url, restoreId: op.restoreId };
  }
  async function externalMessage(message, sender) {
    switch (message?.type) {
      case "DWF_PING":
        return { ok: true, version: chrome.runtime.getManifest().version };
      case "DWF_SAVE_CHECKPOINT": {
        const tab = await activeTab();
        return captureOnTab(tab, typeof message.goal === "string" ? message.goal : "");
      }
      case "DWF_RESTORE":
        return restoreCheckpoint(String(message.id ?? ""));
      case "DWF_LIST": {
        const list = await readCheckpoints();
        return { ok: true, checkpoints: list.map(({ savedFrame, ...rest }) => rest) };
      }
      case "DWF_STATUS":
        return { ok: true, lastResult: (await chrome.storage.local.get(KEYS.lastResult))[KEYS.lastResult] ?? null };
      default:
        return { ok: false, error: "Unknown message." };
    }
  }
  chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
    void externalMessage(message, sender).then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error) }));
    return true;
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "DWF_SAVE_PDF_CHECKPOINT") {
      const viewer = chrome.runtime.getURL("pdf/viewer.html");
      const checkpoint = message.checkpoint;
      if (!checkpoint?.id || !sender.url?.startsWith(viewer) || !checkpoint.url?.startsWith(viewer)) {
        sendResponse({ ok: false, error: "Only the Deep Work Field PDF viewer can save PDF checkpoints." });
        return false;
      }
      void withLock(async () => {
        const list = await readCheckpoints();
        list.unshift(checkpoint);
        await writeCheckpoints(list);
      }).then(() => setBadge("\u25CF", "#45d6ab")).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: String(error) }));
      return true;
    }
    if (message?.type === "DWF_SCREEN") {
      if (sender.tab?.id === streamingTab && ports.size) {
        post({ url: String(message.url ?? ""), title: String(message.title ?? ""), text: String(message.text ?? "").slice(0, 1600), restricted: false });
      }
      return false;
    }
    if (message?.type === "DWF_GET_PENDING") {
      void getPending(sender.tab?.id).then((pending) => sendResponse({ pending })).catch(() => sendResponse({ pending: null }));
      return true;
    }
    if (message?.type === "DWF_VERIFY_RESULT") {
      const result = message.result;
      const tabId = sender.tab?.id;
      const id = String(message.restoreId ?? "");
      void (async () => {
        if (tabId === void 0 || !await settlePending(tabId, id)) {
          sendResponse({ ok: false, stale: true });
          return;
        }
        await chrome.storage.local.set({
          [KEYS.lastResult]: {
            checkpointId: message.checkpointId,
            restoreId: id,
            status: result.ok ? "verified" : result.reason === "ambiguous" ? "ambiguous" : "saved-context",
            reason: result.reason,
            landing: result.landing,
            attempts: result.attempts,
            at: Date.now()
          }
        });
        await setBadge(result.ok ? "\u2713" : "!", result.ok ? "#45d6ab" : "#f0b429");
        sendResponse({ ok: true });
      })();
      return true;
    }
    if (message?.type === "DWF_ANSWER_EDIT") {
      void chrome.storage.local.get(KEYS.session).then((stored) => {
        const session = stored[KEYS.session] ?? {};
        const next = {
          ...session,
          firstQualifyingEditAt: session.firstQualifyingEditAt ?? Date.now(),
          lastEdit: { problemId: message.problemId, chars: message.chars, at: Date.now() }
        };
        void chrome.storage.local.set({ [KEYS.session]: next });
        void setBadge("\u2713", "#45d6ab");
      });
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type === "DWF_SAVE_CHECKPOINT_FROM_POPUP") {
      void activeTab().then((tab) => captureOnTab(tab, String(message.goal ?? ""), message.screenshot === true)).then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error) }));
      return true;
    }
    if (message?.type === "DWF_RESTORE_FROM_POPUP") {
      void restoreCheckpoint(String(message.id ?? "")).then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error) }));
      return true;
    }
    if (message?.type === "DWF_LIST_FROM_POPUP") {
      void readCheckpoints().then((list) => sendResponse({ ok: true, checkpoints: list.map(({ savedFrame, ...rest }) => rest) })).catch((error) => sendResponse({ ok: false, error: String(error) }));
      return true;
    }
    return false;
  });
  var ports = /* @__PURE__ */ new Set();
  var streamingTab = null;
  function post(sample) {
    for (const port of ports) {
      try {
        port.postMessage({ type: "screen", t: Date.now(), ...sample });
      } catch {
        ports.delete(port);
      }
    }
  }
  async function streamActiveTab() {
    if (!ports.size) return;
    const tab = await activeTab().catch(() => null);
    if (!tab?.id) return;
    if (streamingTab !== null && streamingTab !== tab.id) {
      chrome.tabs.sendMessage(streamingTab, { type: "DWF_STREAM", on: false }).catch(() => void 0);
    }
    streamingTab = tab.id;
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "DWF_STREAM", on: true });
    } catch {
      post({ url: tab.url ?? tab.pendingUrl ?? "", title: tab.title ?? "", text: "", restricted: true });
    }
  }
  function stopAllStreams() {
    if (streamingTab !== null) chrome.tabs.sendMessage(streamingTab, { type: "DWF_STREAM", on: false }).catch(() => void 0);
    streamingTab = null;
  }
  chrome.runtime.onConnectExternal.addListener((port) => {
    if (port.name !== "dwf-screen") return;
    ports.add(port);
    port.onDisconnect.addListener(() => {
      ports.delete(port);
      if (!ports.size) stopAllStreams();
    });
    void streamActiveTab();
  });
  chrome.tabs.onActivated.addListener(() => void streamActiveTab());
  chrome.windows.onFocusChanged.addListener(() => void streamActiveTab());
  chrome.tabs.onUpdated.addListener((tabId, info) => {
    if (info.status === "complete" && tabId === streamingTab) void streamActiveTab();
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    void withLock(async () => {
      const map = await readPending();
      const entry = map[String(tabId)];
      if (!entry) return;
      delete map[String(tabId)];
      await chrome.storage.local.set({
        [KEYS.pending]: map,
        [KEYS.lastResult]: { checkpointId: entry.checkpoint.id, restoreId: entry.restoreId, status: "cancelled", reason: "tab-closed", at: Date.now() }
      });
    });
  });
  chrome.runtime.onInstalled.addListener(() => {
    void chrome.storage.local.set({ [KEYS.lastResult]: { status: "installed", at: Date.now() } });
    void setBadge("", "#45d6ab");
  });
})();
