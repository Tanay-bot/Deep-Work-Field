"use strict";
(() => {
  // extension/src/popup.ts
  var $ = (id) => document.getElementById(id);
  var goalInput = $("goal");
  var primary = $("primary");
  var secondary = $("secondary");
  var status = $("status");
  var list = $("list");
  var shot = $("shot");
  var latestBox = $("latest");
  function setStatus(text, kind = "muted") {
    status.textContent = text;
    status.dataset.kind = kind;
  }
  function relative(ts) {
    const seconds = Math.max(0, Math.round((Date.now() - ts) / 1e3));
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.round(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.round(seconds / 3600)}h ago`;
    return `${Math.round(seconds / 86400)}d ago`;
  }
  var esc = (s) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c] ?? c);
  var pageOf = (url) => {
    try {
      const u = new URL(url);
      return `${u.origin}${u.pathname}`;
    } catch {
      return url;
    }
  };
  var latest = null;
  var onSavedPage = false;
  function describeResult(last) {
    if (!last) return;
    const map = {
      pending: ["Restore tab opened; checking the passage\u2026", "busy"],
      verified: [`Verified: back at your place${last.landing === "dom-scroll" ? " (landed by the extension\u2019s scroll)" : ""}.`, "ok"],
      ambiguous: ["Multiple matching passages on that page, so none was picked. Saved context is shown there.", "warn"],
      "saved-context": [`Could not verify (${last.reason}); saved context is shown on the page.`, "warn"],
      cancelled: ["The restore tab was closed before it was checked.", "muted"]
    };
    const hit = map[last.status];
    if (hit && Date.now() - (last.at ?? 0) < 10 * 60 * 1e3) setStatus(hit[0], hit[1]);
  }
  async function restore(id) {
    primary.disabled = true;
    setStatus("Opening your place and checking the passage\u2026", "busy");
    const reply = await chrome.runtime.sendMessage({ type: "DWF_RESTORE_FROM_POPUP", id });
    primary.disabled = false;
    if (!reply?.ok) setStatus(reply?.error ?? "Restore failed.", "warn");
  }
  async function save() {
    const goal = goalInput.value.trim() || "AP Chem unit 4";
    await chrome.storage.local.set({ "dwf:goal": goal, "dwf:screenshot": shot.checked });
    primary.disabled = true;
    secondary.disabled = true;
    setStatus("Saving the passage you selected\u2026", "busy");
    const reply = await chrome.runtime.sendMessage({ type: "DWF_SAVE_CHECKPOINT_FROM_POPUP", goal, screenshot: shot.checked });
    primary.disabled = false;
    secondary.disabled = false;
    if (reply?.ok) {
      setStatus(`Saved \u201C${reply.checkpoint.anchor.slice(0, 60)}\u201D.`, "ok");
      await refresh(false);
    } else {
      setStatus(reply?.error ?? "Could not save.", "warn");
    }
  }
  async function refresh(showResult = true) {
    const stored = await chrome.storage.local.get(["dwf:goal", "dwf:lastResult", "dwf:screenshot"]);
    goalInput.value = stored["dwf:goal"] ?? "AP Chem unit 4";
    shot.checked = stored["dwf:screenshot"] === true;
    let reply = null;
    try {
      reply = await chrome.runtime.sendMessage({ type: "DWF_LIST_FROM_POPUP" });
    } catch {
      reply = null;
    }
    const checkpoints = reply?.checkpoints ?? [];
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    latest = checkpoints[0] ?? null;
    const isPdf = !!tab?.url && /^(https?|file):/.test(tab.url) && /\.pdf$/i.test(new URL(tab.url).pathname);
    const openPdf = $("open-pdf");
    openPdf.hidden = !isPdf;
    openPdf.onclick = () => {
      void chrome.tabs.update(tab.id, { url: chrome.runtime.getURL(`pdf/viewer.html?file=${encodeURIComponent(tab.url)}`) });
      window.close();
    };
    onSavedPage = !!latest && !!tab?.url && pageOf(tab.url) === pageOf(latest.url);
    if (latest) {
      latestBox.hidden = false;
      $("latest-anchor").textContent = latest.anchor;
      $("latest-meta").textContent = `${latest.title} \xB7 saved ${relative(latest.createdAt)}`;
    } else {
      latestBox.hidden = true;
    }
    if (latest && !onSavedPage) {
      primary.textContent = `Return to ${latest.problemId}`;
      secondary.hidden = false;
    } else {
      primary.textContent = "Save this passage";
      secondary.hidden = true;
    }
    const rest = checkpoints.slice(1, 9);
    list.innerHTML = rest.length ? rest.map(
      (c) => `<li><div class="grow"><strong>${esc(c.anchor.slice(0, 80))}</strong><span>${esc(c.title.slice(0, 60))} \xB7 ${relative(c.createdAt)}</span></div><button class="restore" data-id="${esc(c.id)}">Return</button></li>`
    ).join("") : '<li class="empty">No other saved places.</li>';
    list.querySelectorAll(".restore").forEach((b) => b.addEventListener("click", () => void restore(b.dataset.id ?? "")));
    if (showResult) describeResult(stored["dwf:lastResult"]);
  }
  primary.addEventListener("click", () => {
    if (latest && !onSavedPage) void restore(latest.id);
    else void save();
  });
  secondary.addEventListener("click", () => void save());
  shot.addEventListener("change", () => void chrome.storage.local.set({ "dwf:screenshot": shot.checked }));
  goalInput.addEventListener("change", () => void chrome.storage.local.set({ "dwf:goal": goalInput.value.trim() }));
  $("ext-id").textContent = chrome.runtime.id;
  chrome.storage.onChanged.addListener((changes) => {
    if (changes["dwf:lastResult"]) describeResult(changes["dwf:lastResult"].newValue);
  });
  void refresh();
})();
